function showAlert() {
  alert("You clicked the button! 🎉 Welcome to Web Development with ApexPlanet.");
}
